<?php

namespace JsonMachine\Exception;

class PathNotFoundException extends \RuntimeException
{

}
