<?php

namespace JsonMachine\Exception;

class InvalidArgumentException extends \InvalidArgumentException
{

}
